package lr3;
import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите общее кол-во чисел для подсчёта суммы -> ");
        int totalNums = scanner.nextInt();
        scanner.close();

        int[] nums = findAllTargetNums(totalNums);

        sumNumbersWithForEach(nums);
        sumNumbersWithFor(nums);
        sumNumbersWithWhile(nums, totalNums);
    }

    public static int[] findAllTargetNums(int totalLimit) {
        int i = 1;
        int j = 0;
        int[] targetNums = new int[totalLimit];

        while(totalLimit > 0) {
            if(i % 5 == 2 || i % 3 == 1) {
                System.out.printf("%d ", i);
                targetNums[j] = i;
                j++;
                i++;
                totalLimit--;
            }
            i++;
        }
        return targetNums;
    }

    public static void sumNumbersWithForEach(int[] numbers) {
        int sumNums = 0;
        for(int value : numbers) sumNums += value;
        System.out.printf("%nСумма чисел (с помощью цикла foreach): %d", sumNums);
    }

    public static void sumNumbersWithFor(int[] numbers) {
        int sumNums = 0;
        for(int i = 0; i < numbers.length; i++) sumNums += numbers[i];
        System.out.printf("%nСумма чисел (с помощью цикла for): %d", sumNums);
    }

    public static void sumNumbersWithWhile(int[] numbers, int totalLimit) {
        int sumNums = 0;
        while (totalLimit > 0) sumNums += numbers[(--totalLimit)];
        System.out.printf("%nСумма чисел (с помощью цикла while): %d", sumNums);
    }
}
