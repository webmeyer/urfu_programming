package lr3;
import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите название дня в неделе -> ");
        String nameDayOfWeek = scanner.nextLine();

        searchFromCycle(nameDayOfWeek);
        searchFromSwitch(nameDayOfWeek);
    }

    public static void searchFromCycle(String nameDay) {
        String[] daysOfWeek = {"Понедельник", "Вторник", "Среда", "Четверг",
                "Пятница", "Суббота", "Воскресенье"};

        int indexDayOfWeek = 0;
        for(int i = 0; i < daysOfWeek.length; i++) {
            if(nameDay.equalsIgnoreCase(daysOfWeek[i])) {
                indexDayOfWeek = i + 1;
            }
        }

        if(indexDayOfWeek > 0) {
            System.out.printf("Номер дня в неделе -> %d%n", indexDayOfWeek);
        } else {
            System.out.print("Такого дня нет!");
        }
    }

    public static void searchFromSwitch(String nameDay) {
        switch (nameDay.toLowerCase()) {
            case ("понедельник"):
                System.out.println("Номер дня в неделе -> 1");
                break;
            case ("вторник"):
                System.out.println("Номер дня в неделе -> 2");
                break;
            case ("среда"):
                System.out.println("Номер дня в неделе -> 3");
                break;
            case ("четверг"):
                System.out.println("Номер дня в неделе -> 4");
                break;
            case ("пятница"):
                System.out.println("Номер дня в неделе -> 5");
                break;
            case ("суббота"):
                System.out.println("Номер дня в неделе -> 6");
                break;
            case ("воскресенье"):
                System.out.println("Номер дня в неделе -> 7");
                break;
        }
    }
}
