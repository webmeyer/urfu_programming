package lr3;

public class Task8 {
    public static void main(String[] args) {
        int sizeArray = 10;
        char[] mainArray = new char[sizeArray];
        char[] exceptArray = new char[] {'A', 'E', 'I', 'O', 'U', 'Y'};

        createSymArray(mainArray, exceptArray, sizeArray);
    }

    public static void createSymArray(char[] firstArray, char[] excArr, int size) {
        char letter = 'A';
        int i = 0;
        int j = 0;

        for(i = 0; i < size; i++) {
            boolean state = true;
            for(j = 0; j < excArr.length; j++) {
                if(letter == excArr[j]) {
                    i--;
                    state = false;
                    break;
                }
            }

            if(state) {
                firstArray[i] = letter;
                letter++;
            }
        }
        for(int k = 0; k < size; k++) System.out.printf("%c ", firstArray[k]);
    }
}
