package lr3;
import java.util.Scanner;

public class Task4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите первое число -> ");
        int userNum1 = scanner.nextInt();

        System.out.print("Введите второе число -> ");
        int userNum2 = scanner.nextInt();

        System.out.println("Результат с помощью цикла for:");
        findAllNumsWithFor(userNum1, userNum2);

        System.out.printf("%n%nРезультат с помощью цикла while:%n");
        findAllNumsWithWhile(userNum1, userNum2);
    }

    public static void findAllNumsWithFor(int num1, int num2) {
        int minNum;
        int maxNum;

        if(num1 < num2) {
            minNum = num1;
            maxNum = num2;
        } else {
            minNum = num2;
            maxNum = num1;
        }
        for(int i = minNum; i < maxNum + 1; i++) System.out.printf("%d ", i);
    }

    public static void findAllNumsWithWhile(int num1, int num2) {
        int minNum;
        int maxNum;

        if(num1 < num2) {
            minNum = num1;
            maxNum = num2;
        } else {
            minNum = num2;
            maxNum = num1;
        }

        while(minNum <= maxNum) {
            System.out.printf("%d ", minNum);
            minNum++;
        }
    }
}
