package lr3;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Task6 {
    public static void main(String[] args) throws Exception{
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите общее кол-во чисел для подсчёта суммы -> ");

        try {
            int totalNums = scanner.nextInt();

            System.out.println("Список чисел: ");
            findAllTargetNums(totalNums);
        } catch (InputMismatchException excIputMiss) {
            System.out.println("Ошибка при вводе числа! Попробуйте снова!");
        }
        finally {
            scanner.close();
        }
    }

    public static int[] findAllTargetNums(int totalLimit) {
        int i = 1;
        int j = 0;
        int[] targetNums = new int[totalLimit];

        while(totalLimit > 0) {
            if(i % 5 == 2) {
                System.out.printf("%d ", i);
                targetNums[j] = i;
                j++;
                i++;
                totalLimit--;
            }
            i++;
        }
        return targetNums;
    }
}
