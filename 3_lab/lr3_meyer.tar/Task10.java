package lr3;
import java.util.Arrays;
import java.util.Random;

public class Task10 {
    public static void main(String[] args) {
        int[] nums = createRandomIntArray();
        for(int value:getSortedArray(nums)) System.out.printf("%d ", value);
    }

    public static int[] createRandomIntArray() {
        Random random = new Random();
        int arraySize = 23;
        int[] nums = new int[arraySize];

        for(int i = 0; i < nums.length; i++) nums[i] += random.nextInt(5000);
        return nums;
    }

    public static int[] getSortedArray(int[] numsArr) {
        Arrays.sort(numsArr);
        for (int i = 0, j = numsArr.length - 1, tmp; i < j; i++, j--) {
            tmp = numsArr[i];
            numsArr[i] = numsArr[j];
            numsArr[j] = tmp;
        }
        return numsArr;
    }
}
