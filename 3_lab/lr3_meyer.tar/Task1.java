package lr3;
import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число от 1 до 7 -> ");
        int dayOfWeek = scanner.nextInt();

        switch (dayOfWeek){
            case(1):
                System.out.print("Понедельник");
                break;
            case(2):
                System.out.print("Вторник");
                break;
            case(3):
                System.out.print("Среда");
                break;
            case(4):
                System.out.print("Четверг");
                break;
            case(5):
                System.out.print("Пятница");
                break;
            case(6):
                System.out.print("Суббота");
                break;
            case(7):
                System.out.print("Воскресенье");
                break;
            default:
                System.out.print("Некорректное значение");
        }
    }
}
