package lr3;
import java.util.Random;

public class Task9 {
    public static void main(String[] args) {
        int[] nums = createRandomIntArray();

        System.out.printf("Все элементы массива (длина %d):%n", nums.length);
        for (int val : nums) System.out.printf("%d ", val);

        System.out.println();
        showMinValue(nums);
        showMaxValue(nums);
    }
    public static int[] createRandomIntArray() {
        Random random = new Random();
        int arraySize = 23;
        int[] nums = new int[arraySize];

        for(int i = 0; i < nums.length; i++) nums[i] += random.nextInt(5000);
        return nums;
    }

    public static void showMinValue(int[] nums) {
        int minValue = nums[0];
        int minIndex = 0;

        for(int index = 1; index < nums.length; index++) {
            if(nums[index] < minValue){
                minValue = nums[index];
                minIndex = index;
            }
        }
        System.out.printf("Минимальное число в массиве -> %d (индекс %d)%n", minValue, minIndex);
    }

    public static void showMaxValue(int[] nums) {
        int maxValue = nums[0];
        int maxIndex = 0;

        for (int index = 1; index < nums.length; index++) {
            if (nums[index] > maxValue) {
                maxValue = nums[index];
                maxIndex = index;
            }
        }
        System.out.printf("Максимальное число в массиве -> %d (индекс %d)%n", maxValue, maxIndex);
    }
}
