package lr3;
import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите кол-во чисел в последовательности Фибоначчи (целое число) -> ");
        int totalNumbers = scanner.nextInt();

        findFibonacciNumbers(totalNumbers);
    }

    public static void findFibonacciNumbers(int totalNums){
        int num1 = 0;
        int num2 = 1;

        for(int i = 2; i <= totalNums + 1; i++) {
            int nextNum = num1 + num2;
            num1 = num2;
            num2 = nextNum;
            System.out.printf("%d ", num1);
        }
    }
}
