package lr2;
import java.util.Scanner;

public class Task1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число которое делится на 3 без остатка -> ");
        int userNum = scanner.nextInt();
        scanner.close();

        if(userNum % 3 == 0) {
            System.out.println("Правильно! Число делится на 3.");
        } else {
            System.out.printf("Ошибка! Число не делится на 3%nПопробуйте снова!");
        }
    }
}
