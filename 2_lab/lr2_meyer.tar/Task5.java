package lr2;

import java.util.Scanner;

public class Task5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число которое больше 1000 -> ");
        int userNum = scanner.nextInt();
        scanner.close();

        if (userNum > 1000) {
            System.out.printf("Успешно! Выбранное больше 1000. В вашем числе %d тыс.%n", (userNum / 1000));
        } else {
            System.out.printf("Ошибка! Число выбрано неверно.%nПопробуйте снова!");
        }
    }
}
