package lr2;
import java.util.Scanner;

public class Task2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число которое делится на 5 с остатком 2 и на 7 с остатком 1 -> ");
        int userNum = scanner.nextInt();
        scanner.close();

        if (userNum % 5 == 2 && userNum % 7 == 1) {
            System.out.printf("Успешно! Выбранное число делится на 5 с остатком 2 и на 7 с остатком 1.%n");
        } else {
            System.out.printf("Ошибка! Число выбрано неверно.%nПопробуйте снова!");
        }
    }
}
