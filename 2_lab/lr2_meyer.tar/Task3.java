package lr2;
import java.util.Scanner;

public class Task3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число которое больше 10 и делится на 4 без остатка -> ");
        int userNum = scanner.nextInt();
        scanner.close();

        if (userNum % 4 == 0 && userNum > 10) {
            System.out.printf("Успешно! Выбранное больше 10 и делится на 4 без остатка.%n");
        } else {
            System.out.printf("Ошибка! Число выбрано неверно.%nПопробуйте снова!");
        }
    }
}
