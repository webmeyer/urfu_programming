package lr2;

import java.util.Scanner;

public class Task4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите число которое попадает в диапазон от 5 до 10 -> ");
        int userNum = scanner.nextInt();
        scanner.close();

        if (userNum >= 5 && userNum <= 10) {
            System.out.printf("Успешно! Выбранное попадает в диапазон от 5 до 10.%n");
        } else {
            System.out.printf("Ошибка! Число выбрано неверно.%nПопробуйте снова!");
        }
    }
}
