package lr1;
import java.util.Scanner;

public class example_20_14 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String userName = scanner.nextLine();
		
		System.out.print("What is your age (enter full age number): ");
		int userFullAge = scanner.nextInt();
		scanner.close();
		
		int userWasBorn = 2022 - userFullAge;
		System.out.printf("Your name is %s and you was born in %d.%n", userName, userWasBorn);
	}
}
