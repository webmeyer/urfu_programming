package lr1;
import java.lang.Math;

public class example_20_20 {
	static double a = 10.0, b = 4.0, c;
	public static void main(String[] args) {
		System.out.println("katet a = " + a);
		System.out.println("katet b = " + b);
		System.out.printf("hypotenuse: %.2f", hyp(a, b));
	}
	
	public static double hyp(double cathet1, double cathet2) {
		return c = Math.sqrt(customPow(cathet1, 2) + customPow(cathet2, 2));
	}
	
	private static double customPow(double x, double y) {
        return Math.pow(x, y);
    }
}
