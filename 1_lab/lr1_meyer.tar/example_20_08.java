package lr1;
import java.util.Scanner;
import java.util.StringJoiner;

public class example_20_08 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		String[] userdata = {"lastname", "name", "surname"};
		for(int i = 0; i < userdata.length; i++) {
			System.out.printf("Input %s: ", userdata[i]);
			String data = scanner.nextLine();
			userdata[i] = data;
		}
		scanner.close();
		
		StringJoiner data = new StringJoiner(", ");
		for(String value : userdata) {
			data.add(value);
		}

		System.out.printf("«Hallo %s.»%n", data);
		
	}
}
