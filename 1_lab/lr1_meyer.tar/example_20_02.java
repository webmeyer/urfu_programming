package lr1;

public class example_20_02 {

	public static void main(String[] args) {
		int num;
		
		num = 100;
		System.out.println("num: " + num);
		
		num = num * 2;
		System.out.print("Значение num * 2 равно ");
		System.out.println(num);

	}

}
