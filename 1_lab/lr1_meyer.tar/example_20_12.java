package lr1;
import java.util.Scanner;

public class example_20_12 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("When you was born (enter the year): ");
		int userWasBorn = scanner.nextInt();
		scanner.close();
		
		int userAge = 2022 - userWasBorn;
		System.out.printf("You are %d age.%n", userAge);
	}
}
