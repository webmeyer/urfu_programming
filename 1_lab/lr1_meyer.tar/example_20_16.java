package lr1;
import java.util.Scanner;

public class example_20_16 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter a number: ");
		int mainNum = scanner.nextInt();
		scanner.close();
		
		int lessOneNum = mainNum - 1;
		int moreOneNum = mainNum + 1;
		int sqrtAll = (lessOneNum + mainNum + moreOneNum)*(lessOneNum + mainNum + moreOneNum);

		System.out.printf("Result: %d", sqrtAll);
	}
}
