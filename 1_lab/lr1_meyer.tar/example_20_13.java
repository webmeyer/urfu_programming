package lr1;
import java.util.Scanner;

public class example_20_13 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter your name: ");
		String userName = scanner.nextLine();
		
		System.out.print("When you was born (enter the year): ");
		int userWasBorn = scanner.nextInt();
		scanner.close();
		
		int userAge = 2022 - userWasBorn;
		System.out.printf("Your name is %s and your age is %d.%n", userName, userAge);
	}
}
