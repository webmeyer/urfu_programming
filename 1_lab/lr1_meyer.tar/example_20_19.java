package lr1;
import java.lang.Math;

public class example_20_19 {
	static double a = 10.0, b = 4.0, c;
	public static void main(String[] args) {
		System.out.println("katet a = " + a);
		System.out.println("katet b = " + b);
		System.out.printf("hypotenuse: %.2f", hyp(a, b));
	}
	
	public static double hyp(double cathet1, double cathet2) {
		return c = Math.sqrt(customMethod(cathet1, 2) + customMethod(cathet2, 2));
	}
	
	private static double customMethod(double a, double b) {
        return Math.exp(b * Math.log(a));
    }
}
