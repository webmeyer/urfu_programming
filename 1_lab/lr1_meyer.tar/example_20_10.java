package lr1;
import java.util.Scanner;

public class example_20_10 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Input name of day today: ");
		String dayOfWeek = scanner.nextLine();
		
		System.out.print("Input name of month: ");
		String nameOfMonth = scanner.nextLine();
		
		System.out.print("Input date of day: ");
		int dateToday = scanner.nextInt();
		scanner.close();
		
		System.out.printf("Today is %s, %d %s", dayOfWeek, dateToday, nameOfMonth);
		
	}
}
