package lr1;
import java.util.Scanner;

public class example_20_11 {
	public static void main(String[] args) {
		System.out.println("== START PROGRAM ==");
		Scanner scanner = new Scanner(System.in);
		
		String[] listOfMonthName = {"January", "February", "March", "April", "May", "June", "July", 
									"August", "September", "October", "November", "December"};
		
		System.out.print("Input fullname of month: ");
		String nameOfMonth = scanner.nextLine();
		
		// Check input name of month is correctly
		Boolean checkNameOfMonth = false;
		for(String value : listOfMonthName) {
			if(nameOfMonth.toLowerCase().equals(value.toLowerCase())) {
				System.out.printf("Name of month is correct -> %s%n", nameOfMonth.toLowerCase());
				checkNameOfMonth = true;
				break;
			} else {
				checkNameOfMonth = false;
				continue;
				}
			}
		
		if(!checkNameOfMonth) {
			System.out.printf("Your input fullname of month is incorrect -> %s%n. Start again! %n", nameOfMonth);
			scanner.close();
			return;
		}
		
		// Check input user's date of month with real calendar of 2022 year
		while(!nameOfMonth.isEmpty()) {
			System.out.print("Input total days in month: ");
			int totalDaysInMonth = scanner.nextInt();
			
			if(totalDaysInMonth < 28 || totalDaysInMonth > 31) {
				System.out.println("## Wrong total days of month. Check the calendar and try again please!");
				continue;
			} else {
				for(int i = 0; i < listOfMonthName.length; i++) {
					if(nameOfMonth.toLowerCase().equals(listOfMonthName[i].toLowerCase())) {
						if (i % 2 == 0 && totalDaysInMonth != 31) {
							System.out.printf("#1 Wrong days for %s. Check the calendar and try again please!%n", listOfMonthName[i].toLowerCase());
							break;
						} else if(i % 2 == 1) {
							if (nameOfMonth.toLowerCase().equals("february")) {
								if(2022 % 4 != 0 && totalDaysInMonth != 28) {
									System.out.printf("#2 Wrong total todays in February! Try again!%n", totalDaysInMonth);
									break;
								} else {
									System.out.printf(">> The %s have a %d days.%n", nameOfMonth, totalDaysInMonth);
									nameOfMonth = "";
									scanner.close();
									break;
								}
							} else if(totalDaysInMonth != 30) {
								System.out.printf("#3 Wrong days for %s. Check the calendar and try again please!%n", listOfMonthName[i].toLowerCase());
								break;
							}  else {
								System.out.printf(">> The %s have a %d days.%n", nameOfMonth, totalDaysInMonth);
								nameOfMonth = "";
								scanner.close();
								break;
							}
						} else {
							System.out.printf(">> The %s have a %d days.%n", nameOfMonth, totalDaysInMonth);
							nameOfMonth = "";
							scanner.close();
							break;
						}
					} 
				}
			}
				continue;
		}
		System.out.println("==END PROGRAM==");
	}		
}

