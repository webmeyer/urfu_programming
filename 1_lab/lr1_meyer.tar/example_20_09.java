package lr1;
import java.util.Scanner;

public class example_20_09 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.printf("Input your name: ");
		String name = scanner.nextLine();
		
		System.out.printf("Input your age: ");
		int age = scanner.nextInt();
		scanner.close();
		
		System.out.printf("Your name is %s, your age is %d.%n", name, age);
		
	}
}
