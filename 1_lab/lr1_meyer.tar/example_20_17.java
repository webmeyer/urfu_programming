package lr1;
import java.util.Scanner;

public class example_20_17 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter first number: ");
		int firstNum = scanner.nextInt();
		
		System.out.print("Enter second number: ");
		int secondNum = scanner.nextInt();
		scanner.close();
		
		int sumNumbers = firstNum + secondNum;
		int diffNumbers = firstNum - secondNum;
		
		System.out.printf(">> The sum of numbers: %d%n", sumNumbers);
		System.out.printf(">> The diff of numbers: %d", diffNumbers);
	}
}
