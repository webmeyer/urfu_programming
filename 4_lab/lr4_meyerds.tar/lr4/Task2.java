package lr4;

public class Task2 {
    public static void main(String[] args) {
        showTriangle(15);
    }

    public static void showTriangle(int height) {
        int z = 0;
        for (int i = 1; i <= height; i++, z++) {
            for (int j = 0; j <= z; j++) System.out.print("+");
            System.out.println();
        }
    }
}
