package lr4;

public class Task1 {
    public static void main(String[] args) {
        showRectangle(11, 23);
    }

    public static void showRectangle (int rows, int cols) {
        for (int i = 1 ; i <= rows; i++){
            for (int j = 1; j <=cols; j++) System.out.print("+");
            System.out.println();
        }
    }
}
